﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using SuperSimpleTcp;
using System.ComponentModel;
using Client.BL;
using Client.DAL;

namespace WpfMVVMClient.ViewModel
{
    class ViewModelClient : ObservableObject 
	{
		private string? idclient;
		private string? message;


		public ObservableCollection<NouveauClient>? Clients { get; set; }

		public ObservableCollection<Message>? Messages { get; set; }


		public IRelayCommand? AddClient { get; set; }

		public IRelayCommand? AddMessage { get; set; }


		public string Idclient
		{
			get => idclient;
			set => SetProperty(ref idclient, value);
		}

		public string Message
		{
			get => message;
			set => SetProperty(ref message, value);
		}

		

		private SimpleTcpClient _client;
        private string? _txtMsg;
        private string _textIP;
		private string _txtInfo;
        public string TxtMsg
        {
            get => _txtMsg;
            set => SetProperty(ref _txtMsg, value);
        }
        public string TextIP
		{
			get => _textIP; 
			set => SetProperty(ref _textIP, value);
		}

		

		public string TxtInfo
		{
			get => _txtInfo;
			set => SetProperty(ref _txtInfo, value);
		}
		private void OnConnected()
		{
			Application.Current.Dispatcher.Invoke(() =>
			{
				TxtInfo += $"Server connected {Environment.NewLine}";
			});
		}
		private void OnDisconnected()
		{
			Application.Current.Dispatcher.Invoke(() =>
			{
				TxtInfo += $"Server disconnected {Environment.NewLine}";
			});
		}
		private void OnDataReceived(object? sender, DataReceivedEventArgs e)
		{
			Application.Current.Dispatcher.Invoke(() =>
		{
			 TxtInfo += $"Server: {Encoding.UTF8.GetString(e.Data)} {Environment.NewLine}";
		});
		}

		private void Connect()
		{
			try
			{
				_client.Connect();
				
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Message", MessageBoxButton.OK, MessageBoxImage.Error);
			}
		}

		private void Send()
		{
			if (_client.IsConnected && !string.IsNullOrEmpty(TxtMsg))
			{
				_client.Send(TxtMsg);
				TxtInfo += $"Me : {TxtMsg}{Environment.NewLine}";
				TxtMsg = string.Empty;
			}
		}
		

		private void AddClientAndConnect()
		{
			try
			{

				NouveauClient cl = new NouveauClient { id_client = idclient };

				ManipulationDB.AddClient(cl);

				MessageBox.Show("New Client added!");

				_client.Connect();
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Error: {ex.Message}");
			}
		}


		private void AddMessageAndSend()
		{
			try
			{
				NouveauClient client = ManipulationDB.GetClientByPseudo(idclient);

				if (client == null)
				{
					MessageBox.Show("Client not found!");
					return;
				}

				if (_client.IsConnected && !string.IsNullOrEmpty(message))
				{
					_client.Send(Message);

					Message msg = new Message { message = message, CurrentClientId = client.Id };

					ManipulationDB.AddMessage(msg);

					Application.Current.Dispatcher.Invoke(() =>
					{
						TxtInfo += $"Me : {message}{Environment.NewLine}";
						
					});
					
					MessageBox.Show("Message sent and New Message added!");

					
				}
				else
				{
					MessageBox.Show("Connection is not established or the message is empty.");
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Error: {ex.Message}");
			}
			
		}




		public ViewModelClient()
		{
			Clients = new ObservableCollection<NouveauClient>();
			AddClient = new RelayCommand(AddClientAndConnect);

			Messages = new ObservableCollection<Message>();
			AddMessage = new RelayCommand(AddMessageAndSend);

			//_client = new SimpleTcpClient(TextIP);
			//_client = new SimpleTcpClient(string.IsNullOrEmpty(TextIP) ? "127.0.0.1:9000" : TextIP);
			string defaultIpAddress = "127.0.0.1";
			string defaultPort = "9000";//9000 : valeur par défaut

			string ipAddressAndPort = string.IsNullOrEmpty(TextIP)
				? $"{defaultIpAddress}:{defaultPort}"
				: TextIP; 

			_client = new SimpleTcpClient(ipAddressAndPort);

			_client.Events.Connected += (sender, e) => OnConnected();
			_client.Events.Disconnected += (sender, e) => OnDisconnected();
			_client.Events.DataReceived += (sender, e) => OnDataReceived(sender, e);
		}

	}
}


