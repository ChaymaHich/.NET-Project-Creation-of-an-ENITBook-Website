﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SuperSimpleTcp;
using System.ComponentModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Collections.ObjectModel;
using System.Windows.Input;
using System.Windows;


namespace WpfMVVM.ViewModel
{
	public class ViewModelServeur : ObservableObject
	{
		private SimpleTcpServer _server;
		private string _textIP;
		private string _txtMsg;
		private string _txtInfo;
		private ObservableCollection<string> _clientList;

		private string _selectedClient;
		public string SelectedClient
		{
			get => _selectedClient;
			set => SetProperty(ref _selectedClient, value);
		}


		public string TextIP
		{
			get => _textIP;
			set => SetProperty(ref _textIP, value);
		}

		public string TxtMsg
		{
			get => _txtMsg;
			set => SetProperty(ref _txtMsg, value);
		}

		public string TxtInfo
		{
			get => _txtInfo;
			set => SetProperty(ref _txtInfo, value);
		}

		public ObservableCollection<string> ClientList
		{
			get => _clientList;
			set => SetProperty(ref _clientList, value);
		}

		public ICommand StartCommand { get; }
		public ICommand SendCommand { get; }

		/*private void StartServer()
		{
			_server.Start();
			TxtInfo += $"Server started...{Environment.NewLine}";
		}*/

		private void StartServer()
		{
			
			string[] addressParts = TextIP.Split(':');

			if (addressParts.Length == 2 && int.TryParse(addressParts[1], out int port))
			{
				_server = new SimpleTcpServer(addressParts[0], port);
				_server.Events.ClientConnected += Events_ClientConnected;
				_server.Events.ClientDisconnected += Events_ClientDisconnected;
				_server.Events.DataReceived += Events_DataReceived;

				_server.Start();
				TxtInfo += $"Server started at {TextIP}...{Environment.NewLine}";
			}
			else
			{
				TxtInfo += "Invalid IP address or port.";
			}
		}

		private void SendMessage()
		{
			if (_server.IsListening && !string.IsNullOrEmpty(TxtMsg) && !string.IsNullOrEmpty(SelectedClient))
			{
				_server.Send(SelectedClient, TxtMsg);
				TxtInfo += $"Server to {SelectedClient}: {TxtMsg} {Environment.NewLine}";
				TxtMsg = string.Empty;
			}
		}

		private void Events_ClientConnected(object sender, ConnectionEventArgs e)
		{
			Application.Current.Dispatcher.Invoke(() =>
			{
				TxtInfo += $"{e.IpPort} : connected {Environment.NewLine}";
				ClientList.Add(e.IpPort);
			});
		}

		private void Events_ClientDisconnected(object sender, ConnectionEventArgs e)
		{
			Application.Current.Dispatcher.Invoke(() =>
			{
				TxtInfo += $"{e.IpPort} : disconnected {Environment.NewLine}";
				ClientList.Remove(e.IpPort);
			});
		}

		private void Events_DataReceived(object sender, DataReceivedEventArgs e)
		{
			Application.Current.Dispatcher.Invoke(() =>
			{
				TxtInfo += $"{e.IpPort} : {Encoding.UTF8.GetString(e.Data)} {Environment.NewLine}";
			});
		}

		public ViewModelServeur()
		{
			_clientList = new ObservableCollection<string>();
			/*_server = new SimpleTcpServer("127.0.0.1", 9000); //
			_server.Events.ClientConnected += Events_ClientConnected;
			_server.Events.ClientDisconnected += Events_ClientDisconnected;
			_server.Events.DataReceived += Events_DataReceived;*/

			StartCommand = new RelayCommand(StartServer);
			SendCommand = new RelayCommand(SendMessage);
		}


	}
}
