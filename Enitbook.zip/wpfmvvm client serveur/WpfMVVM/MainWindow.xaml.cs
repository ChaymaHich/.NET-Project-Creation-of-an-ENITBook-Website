﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SuperSimpleTcp;


namespace WpfMVVM
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	/// 

	public partial class MainWindow : Window
	{
		
		public MainWindow()
		{
			InitializeComponent();
		}
		SimpleTcpServer server;
		private void Button_Click(object sender, RoutedEventArgs e)
		{
			if (server.IsListening)
			{
				if (!string.IsNullOrEmpty(txtMsg.Text) && listCilentIP.SelectedItem != null)
				{
					server.Send(listCilentIP.SelectedItem.ToString(), txtMsg.Text);
					txtInfo.Text += $"Server : {txtMsg.Text} {Environment.NewLine}";
					txtMsg.Text = string.Empty;
				}
			}
		}

		private void btnstart_Click(object sender, RoutedEventArgs e)
		{
			btnsend.IsEnabled = true;
			btnstart.IsEnabled = false;
			server.Start();
			txtInfo.Text = $"Starting...{Environment.NewLine}";
		}

		private void Grid_Loaded(object sender, RoutedEventArgs e)
		{
			server = new SimpleTcpServer(TextIP.Text);
			btnsend.IsEnabled = false;
			server.Events.ClientConnected += Events_ClientConnected;
			server.Events.ClientDisconnected += Events_ClientDisconnected;
			server.Events.DataReceived += Events_DataReceived;
		}

		private void Events_ClientConnected(object? sender, ConnectionEventArgs e)
		{
			Dispatcher.Invoke(() =>
			{
				txtInfo.Text += $"{e.IpPort} : connected {Environment.NewLine}";
				listCilentIP.Items.Add(e.IpPort);
			});
		}

		private void Events_ClientDisconnected(object? sender, ConnectionEventArgs e)
		{
			//txtInfo.Text = $"{e.IpPort} : Disconnected {Environment.NewLine}";
			//lstclientIP.Items.Remove(e.IpPort);

			Dispatcher.Invoke(() =>
			{
				txtInfo.Text += $"{e.IpPort} : disconnected {Environment.NewLine}";
				listCilentIP.Items.Remove(e.IpPort);
			});

		}

		private void Events_DataReceived(object? sender, DataReceivedEventArgs e)
		{
			//TextInfo.Text = $"{e.IpPort} : {Encoding.UTF8.GetString(e.Data)}";

			Dispatcher.Invoke(() =>
			{
				txtInfo.Text += $"{e.IpPort} : {Encoding.UTF8.GetString(e.Data)} {Environment.NewLine}";
			});
		}
	}
}
