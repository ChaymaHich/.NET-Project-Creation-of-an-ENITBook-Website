﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Client.BL;
using Microsoft.EntityFrameworkCore;


namespace Client.DAL
{
	public class Clientcontext : DbContext
	{
		public DbSet<NouveauClient>? Clients { get; set; }

		public DbSet<Message>? Messages { get; set; }

		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
			optionsBuilder.UseSqlServer("server=(LocalDB)\\MSSQLLocalDB;Initial Catalog=MyClientDB;Integrated Security = true");
		}

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{

			modelBuilder.Entity<Message>()
				.HasOne<NouveauClient>(s => s.Client)
				.WithMany(g => g.Messages)
				.HasForeignKey(s => s.CurrentClientId);
		}
	}
}
