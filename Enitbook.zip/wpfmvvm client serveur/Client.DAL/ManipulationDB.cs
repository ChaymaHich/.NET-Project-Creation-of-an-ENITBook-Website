﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Client.BL;
using System.Linq;


namespace Client.DAL
{
	public static class ManipulationDB
	{
		public static Clientcontext dx = new Clientcontext();

		public static void AddClient(NouveauClient a)
		{
			dx.Clients.Add(a);
			dx.SaveChanges();
		}

		public static void AddMessage(Message msg)
		{
			dx.Messages.Add(msg);
			dx.SaveChanges();
		}
		public static NouveauClient GetClientByPseudo(string pseudo)
		{
			var client = dx.Clients.FirstOrDefault(c => c.id_client == pseudo);

			return client;
		}
	}
}
