﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client.BL
{
	public class NouveauClient
	{
		
		public int Id { get; set; }
		
		public string? id_client { get; set; }

		public virtual List<Message> Messages { get; set; }

	}
}
