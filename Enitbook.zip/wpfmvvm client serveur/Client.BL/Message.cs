﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client.BL
{
	public class Message
	{
		public int MessageId { get; set; }

		//[MaxLength(50), MinLength(2)]
		public string? message { get; set; }
		public int? CurrentClientId { get; set; } 
		public NouveauClient Client { get; set; }
	}
}
